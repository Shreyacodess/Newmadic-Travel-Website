from django.urls import path


from . import views

urlpatterns = [
    path("", views.home, name="home"),
    path("home", views.home, name="home"),
    path("index", views.home, name="index"),

    path("blog", views.blog, name="blog"),
    path("gallery", views.gallery, name="gallery"),
    path("explore", views.explore, name="explore"),
    path("special", views.special, name="special"),
    path("base", views.base, name="base"),
    path("login", views.login, name="login"),
    path("signup", views.signup, name="signup"),
    path("aboutus", views.aboutus, name="aboutus"),
    path("logout", views.logout, name="logout"),






]
