from django.db import models


# Create your models here.
class special_package(models.Model):
    img = models.ImageField(upload_to='')
    de_name = models.CharField(max_length=100)
    price = models.IntegerField()
    review_star = models.IntegerField()
    review_no = models.IntegerField()


class navbar(models.Model):
    name = models.CharField(max_length=50)
    link = models.CharField(max_length=50)


class about(models.Model):
    name = models.CharField(max_length=100)
    image = models.ImageField(upload_to='')
    description = models.CharField(max_length=500)


class result(models.Model):
    username_res = models.CharField(max_length=100)
    dest = models.CharField(max_length=100)
    travel_date = models.DateField()
    check_in = models.DateField()
    check_out = models.DateField()
    duration = models.IntegerField()
    member = models.IntegerField()
    flight_start = models.CharField(max_length=100)
    departure_date = models.DateField()
    return_date = models.DateField()
    adults = models.IntegerField()
    children = models.IntegerField()
    flight_dest = models.CharField(max_length=100)
    flight_class = models.CharField(max_length=50)
