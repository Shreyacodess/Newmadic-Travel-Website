from django.contrib import admin
from .models import special_package, navbar, about, result

# Register your models here.

admin.site.register(special_package)
admin.site.register(navbar)
admin.site.register(about)
admin.site.register(result)


