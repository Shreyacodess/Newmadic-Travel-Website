from django.contrib import messages
from django.contrib.auth.models import User, auth
from django.shortcuts import render, redirect

from .models import special_package, about, result


# Create your views here.


def home(request):
    return render(request, "home.html")


def blog(request):
    return render(request, "blog.html")


def gallery(request):
    return render(request, "gallery.html")


def explore(request):
    return render(request, "explore.html")


def index(request):
    return render(request, "index.html")


def special(request):
    spec = special_package.objects.all()

    return render(request, "special.html", {'spec': spec})


def base(request):
    if request.method == 'POST':
        username_res = request.POST['username_res']
        dest = request.POST['dest']
        travel_date = request.POST['travel_date']
        check_in = request.POST['check_in']
        check_out = request.POST['check_out']
        duration = request.POST['duration']
        member = request.POST['member']
        flight_start = request.POST['flight_start']
        departure_date = request.POST['departure_date']
        return_date = request.POST['return_date']
        adults = request.POST['adults']
        children = request.POST['children']
        flight_dest = request.POST['flight_dest']
        flight_class = request.POST['flight_class']

        final = result(username=username_res, dest=dest, travel_date=travel_date, check_in=check_in,
                       check_out=check_out, duration=duration,
                       member=member, flight_start=flight_start,
                       departure_date=departure_date, return_date=return_date, adults=adults, children=children,
                       flight_dest=flight_dest,
                       flight_class=flight_class)
        final.save()
        messages.info("Your packages is booked, get your bags ready for the trip!")
        res = result.objects.get(username=username_res)
        print(res)
        return redirect(request, "base.html", {'res': res})

    else:
        return render(request, "base.html")


def login(request):
    if request.method == 'POST':
        username1 = request.POST['username']
        password1 = request.POST['pass']
        x = auth.authenticate(username=username1, password=password1)
        if x is None:
            messages.info(request, 'Invalid credentials')
            return redirect("/login")
        else:
            auth.login(request, x)
            return redirect("/")
    else:
        return render(request, "login.html")


def signup(request):
    if request.method == "POST":
        firstname = request.POST['namef']
        lastname = request.POST['namel']
        email = request.POST['email']
        username = request.POST['username']
        password = request.POST['pass']
        if User.objects.filter(username=username).exists():
            messages.info(request, 'Username taken')
            return redirect("/signup")
        if User.objects.filter(email=email).exists():
            messages.info(request, 'Email already exists,use another email id to proceed')
            return redirect("/signup")
        else:
            user = User.objects.create_user(first_name=firstname, last_name=lastname, email=email, password=password,
                                            username=username)
            user.save()
            messages.info(request, 'Sign up successful')
            return redirect("/login")

    else:
        return render(request, "signup.html")


def aboutus(request):
    ab = about.objects.all()
    return render(request, "aboutus.html", {'ab': ab})


def logout(request):
    auth.logout(request)
    return redirect("/")
